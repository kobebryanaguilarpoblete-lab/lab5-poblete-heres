const amqp = require("amqplib");

const BROKER_URL =
    process.env.BROKER_URL ||
    "amqp://guest:guest@localhost:5672";


async function start() {

    while (true) {

        try {

            console.log(
                "Connecting Notification Service to RabbitMQ..."
            );


            const connection =
                await amqp.connect(BROKER_URL);


            const channel =
                await connection.createChannel();


            await channel.assertExchange(
                "shop_events",
                "topic",
                {
                    durable: true
                }
            );


            const queue =
                await channel.assertQueue(

                    "notification_payment_queue",

                    {
                        durable: true
                    }

                );


            await channel.bindQueue(

                queue.queue,

                "shop_events",

                "payment.success"

            );


            console.log(
                "Notification Service is waiting for payments..."
            );


            channel.consume(

                queue.queue,

                (message) => {

                    if (!message) {
                        return;
                    }


                    try {

                        const payment =
                            JSON.parse(
                                message.content.toString()
                            );


                        console.log(
                            "================================"
                        );

                        console.log(
                            "NOTIFICATION SERVICE"
                        );

                        console.log(
                            `Order ID: ${payment.orderId}`
                        );

                        console.log(
                            `Customer: ${payment.customerName}`
                        );

                        console.log(
                            `Payment Status: ${payment.status}`
                        );

                        console.log(
                            "Notification sent successfully."
                        );

                        console.log(
                            "================================"
                        );


                        channel.ack(message);


                    } catch (error) {

                        console.error(error);


                        channel.nack(
                            message,
                            false,
                            false
                        );

                    }

                }

            );


            break;


        } catch (error) {

            console.log(
                "RabbitMQ unavailable. Retrying..."
            );


            await new Promise(
                resolve => setTimeout(resolve, 5000)
            );

        }

    }

}


start();
