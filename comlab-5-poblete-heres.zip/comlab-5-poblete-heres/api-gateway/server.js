const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();

const PORT = 8080;

const ORDER_SERVICE_URL =
    process.env.ORDER_SERVICE_URL ||
    "http://localhost:3000";

const CORS_ORIGIN =
    process.env.CORS_ORIGIN ||
    "http://localhost:3000";


app.use(cors({
    origin: CORS_ORIGIN
}));

app.use(express.json());


app.get("/", (req, res) => {

    res.json({
        service: "API Gateway",
        status: "running"
    });

});


app.get("/health", (req, res) => {

    res.json({
        status: "healthy"
    });

});


app.post("/api/orders", async (req, res) => {

    try {

        const response = await axios.post(

            `${ORDER_SERVICE_URL}/orders`,

            req.body

        );


        res.status(response.status).json(
            response.data
        );


    } catch (error) {

        console.error(
            "Order Service Error:",
            error.message
        );


        res.status(500).json({

            success: false,

            message:
                "Unable to connect to Order Service"

        });

    }

});


app.listen(PORT, () => {

    console.log(
        `API Gateway running on port ${PORT}`
    );

});
