const amqp = require("amqplib");

const BROKER_URL =
    process.env.BROKER_URL ||
    "amqp://guest:guest@localhost:5672";


async function start() {

    while (true) {

        try {

            console.log(
                "Connecting Inventory Service to RabbitMQ..."
            );


            const connection =
                await amqp.connect(BROKER_URL);


            const channel =
                await connection.createChannel();


            await channel.assertExchange(
                "shop_events",
                "topic",
                {
                    durable: true
                }
            );


            const queue =
                await channel.assertQueue(
                    "inventory_order_queue",
                    {
                        durable: true
                    }
                );


            await channel.bindQueue(

                queue.queue,

                "shop_events",

                "order.placed"

            );


            console.log(
                "Inventory Service is waiting for orders..."
            );


            channel.consume(

                queue.queue,

                (message) => {

                    if (!message) {
                        return;
                    }


                    try {

                        const order =
                            JSON.parse(
                                message.content.toString()
                            );


                        console.log(
                            "================================"
                        );

                        console.log(
                            "INVENTORY SERVICE"
                        );

                        console.log(
                            `Order ID: ${order.orderId}`
                        );

                        console.log(
                            `Product: ${order.product}`
                        );

                        console.log(
                            `Quantity: ${order.quantity}`
                        );

                        console.log(
                            "Inventory updated."
                        );

                        console.log(
                            "================================"
                        );


                        channel.ack(message);


                    } catch (error) {

                        console.error(error);

                        channel.nack(
                            message,
                            false,
                            false
                        );

                    }

                }

            );


            break;


        } catch (error) {

            console.log(
                "RabbitMQ unavailable. Retrying..."
            );


            await new Promise(
                resolve => setTimeout(resolve, 5000)
            );

        }

    }

}


start();
