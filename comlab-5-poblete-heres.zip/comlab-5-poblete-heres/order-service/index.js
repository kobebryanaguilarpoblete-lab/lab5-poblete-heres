const express = require("express");
const amqp = require("amqplib");
const crypto = require("crypto");

const app = express();

const PORT = 3000;

const BROKER_URL =
    process.env.BROKER_URL ||
    "amqp://guest:guest@localhost:5672";


app.use(express.json());


let channel = null;


async function connectRabbitMQ() {

    while (!channel) {

        try {

            console.log(
                "Connecting Order Service to RabbitMQ..."
            );


            const connection =
                await amqp.connect(BROKER_URL);


            channel =
                await connection.createChannel();


            await channel.assertExchange(
                "shop_events",
                "topic",
                {
                    durable: true
                }
            );


            console.log(
                "Order Service connected to RabbitMQ"
            );


        } catch (error) {

            console.log(
                "RabbitMQ unavailable. Retrying..."
            );

            await new Promise(
                resolve => setTimeout(resolve, 5000)
            );

        }

    }

}


app.get("/", (req, res) => {

    res.json({
        service: "Order Service",
        status: "running"
    });

});


app.post("/orders", async (req, res) => {

    try {

        const {
            customerName,
            product,
            quantity
        } = req.body;


        if (
            !customerName ||
            !product ||
            !quantity
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "customerName, product and quantity are required"

            });

        }


        const order = {

            orderId:
                crypto.randomUUID(),

            customerName,

            product,

            quantity: Number(quantity),

            createdAt:
                new Date().toISOString()

        };


        const message =
            Buffer.from(
                JSON.stringify(order)
            );


        channel.publish(

            "shop_events",

            "order.placed",

            message,

            {
                persistent: true
            }

        );


        console.log(
            "EVENT: order.placed",
            order
        );


        res.status(201).json({

            success: true,

            message:
                "Order placed successfully",

            order

        });


    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,

            message:
                "Failed to place order"

        });

    }

});


app.listen(PORT, () => {

    console.log(
        `Order Service running on port ${PORT}`
    );

    connectRabbitMQ();

});
