const amqp = require("amqplib");

const BROKER_URL =
    process.env.BROKER_URL ||
    "amqp://guest:guest@localhost:5672";


async function start() {

    while (true) {

        try {

            console.log(
                "Connecting Payment Service to RabbitMQ..."
            );


            const connection =
                await amqp.connect(BROKER_URL);


            const channel =
                await connection.createChannel();


            await channel.assertExchange(
                "shop_events",
                "topic",
                {
                    durable: true
                }
            );


            const queue =
                await channel.assertQueue(
                    "payment_order_queue",
                    {
                        durable: true
                    }
                );


            await channel.bindQueue(

                queue.queue,

                "shop_events",

                "order.placed"

            );


            console.log(
                "Payment Service is waiting for orders..."
            );


            channel.consume(

                queue.queue,

                async (message) => {

                    if (!message) {
                        return;
                    }


                    try {

                        const order =
                            JSON.parse(
                                message.content.toString()
                            );


                        console.log(
                            "Payment processing:",
                            order.orderId
                        );


                        // Simulated payment
                        const payment = {

                            orderId:
                                order.orderId,

                            customerName:
                                order.customerName,

                            amount:
                                order.quantity * 100,

                            status:
                                "SUCCESS",

                            paidAt:
                                new Date().toISOString()

                        };


                        channel.publish(

                            "shop_events",

                            "payment.success",

                            Buffer.from(
                                JSON.stringify(payment)
                            ),

                            {
                                persistent: true
                            }

                        );


                        console.log(
                            "EVENT: payment.success",
                            payment
                        );


                        channel.ack(message);


                    } catch (error) {

                        console.error(
                            "Payment error:",
                            error
                        );


                        channel.nack(
                            message,
                            false,
                            false
                        );

                    }

                }

            );


            break;


        } catch (error) {

            console.log(
                "RabbitMQ unavailable. Retrying..."
            );


            await new Promise(
                resolve => setTimeout(resolve, 5000)
            );

        }

    }

}


start();
